import os

class Migration():

    def __init__(self, db):
        self.db = db

    def forwards(self):
        """Forwards Migration"""

    def backwards(self):
        """Backwards Migration"""
