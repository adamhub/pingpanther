$(document).ready(function() {
    $('#pingpanther_update_btn').click(function(){
        $(this).attr('disabled', 'disabled');
        $.ajax({
            type: 'GET',
            url: url_base+"/update",
            success: function(data) 
            {
                $(this).removeAttr('disabled');
                if (data.error != '')
                {
                    show_alert(data.error, 'alert-error');
                }
                else
                {
                    show_alert("Pingpanther updated", 'alert-success');
                }
            }	
        });
    });
});
