import os

PINGPANTHER_ROOT = os.path.abspath(os.path.dirname(__file__))
DB_FILE = os.path.join(PINGPANTHER_ROOT, 'pingpanther.db')
CRON_FREQUENCY = 1
UPDATE_URL = "http://106.187.91.221/pingpanther/pingpanther.py/media/pingpanther.tar.gz"

TWILIO_ACCOUNT = "AC546f66dd384a25b14024fcba9838e9b8"
TWILIO_TOKEN = "7cbc320e412281a5da698fc3d4431ef1"

try:
    from local_settings import *
except ImportError:
    pass
